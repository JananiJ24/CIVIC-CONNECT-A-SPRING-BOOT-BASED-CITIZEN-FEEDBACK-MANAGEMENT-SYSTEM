package com.hb.cda.springblog.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.User;

@Repository
public interface PostRepository extends JpaRepository<Post, String> {

    // Existing - used for pagination
    Page<Post> findByAuthor(User author, Pageable pageable);

    // Existing - used in posts list
    @EntityGraph(attributePaths = {"author"})
    Page<Post> findAll(Pageable pageable);

    // ✅ NEW — Used for profile page
    List<Post> findByAuthor(User author);

    // ✅ NEW — Count total posts by user
    long countByAuthor(User author);
}