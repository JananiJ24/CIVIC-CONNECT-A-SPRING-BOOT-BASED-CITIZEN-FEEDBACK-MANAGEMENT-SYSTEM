package com.hb.cda.springblog.controller.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class UserRegisterDTO {
    @NotBlank
    private String username;
    @NotBlank
    @Size(min = 4, max = 64, message = "Le mot de passe doit faire entre 4 et 64 caractères")
    private String password;
    @NotBlank
    private String repeatPassword;

    public UserRegisterDTO() {
    }

    public UserRegisterDTO(@NotBlank String username,
            @NotBlank @Size(min = 4, max = 64, message = "Le mot de passe doit faire entre 4 et 64 caractères") String password,
            String repeatPassword) {
        this.username = username;
        this.password = password;
        this.repeatPassword = repeatPassword;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getRepeatPassword() {
        return repeatPassword;
    }
    public void setRepeatPassword(String repeatPassword) {
        this.repeatPassword = repeatPassword;
    }

}
