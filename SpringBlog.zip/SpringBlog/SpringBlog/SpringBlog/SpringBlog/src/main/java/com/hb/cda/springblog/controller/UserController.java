package com.hb.cda.springblog.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.User;
import com.hb.cda.springblog.repository.CommentRepository;
import com.hb.cda.springblog.repository.PostRepository;
import com.hb.cda.springblog.repository.ReactionRepository;
import com.hb.cda.springblog.repository.UserRepository;

import jakarta.transaction.Transactional;

@Controller
public class UserController {

    private final PostRepository postRepo;
    private final ReactionRepository reactRepo;
    private final CommentRepository commentRepo;
    private final UserRepository userRepo;

    public UserController(PostRepository postRepo,
                          ReactionRepository reactRepo,
                          CommentRepository commentRepo,
                          UserRepository userRepo) {
        this.postRepo = postRepo;
        this.reactRepo = reactRepo;
        this.commentRepo = commentRepo;
        this.userRepo = userRepo;
    }

    // ✅ User profile page
    @GetMapping("/profile")
    public String profile(@AuthenticationPrincipal User user, Model model) {
        if (user == null) return "redirect:/login";

        // Reload user to ensure fresh data from DB
        User freshUser = userRepo.findById(user.getId()).orElse(user);

        model.addAttribute("user", freshUser);
        model.addAttribute("posts", postRepo.findByAuthor(freshUser));
        model.addAttribute("postsCount", postRepo.countByAuthor(freshUser));

        // Reactions count map
        Map<String, Integer> reactionCounts = reactRepo.countByReactionTypeForUserMap(freshUser);
        if (reactionCounts == null) reactionCounts = new HashMap<>();
        reactionCounts.putIfAbsent("Like", 0);
        reactionCounts.putIfAbsent("Neutral", 0);
        reactionCounts.putIfAbsent("Dislike", 0);
        model.addAttribute("reactionCounts", reactionCounts);

        // Comment count
        model.addAttribute("commentCount", commentRepo.countByUser(freshUser));

        return "profile";
    }

    // ✅ Delete post (with child cleanup)
    @PostMapping("/profile/post/{postId}/delete")
    @Transactional
    public String deletePost(@PathVariable String postId,
                             @AuthenticationPrincipal User user,
                             RedirectAttributes ra) {

        if (user == null) {
            ra.addFlashAttribute("error", "Login required");
            return "redirect:/login";
        }

        Post post = postRepo.findById(postId).orElse(null);
        if (post == null) {
            ra.addFlashAttribute("error", "Post not found");
            return "redirect:/profile";
        }

        // Only the author can delete their post
        if (!post.getAuthor().getId().equals(user.getId())) {
            ra.addFlashAttribute("error", "You can only delete your own posts");
            return "redirect:/profile";
        }

        try {
            // ✅ Delete all related reactions first
            reactRepo.deleteAllByPost(post);

            // ✅ Then delete all related comments
            commentRepo.deleteAllByPost(post);

            // ✅ Finally delete the post itself
            postRepo.delete(post);

            ra.addFlashAttribute("message", "Post deleted successfully");

        } catch (Exception e) {
            e.printStackTrace();
            ra.addFlashAttribute("error", "Error deleting post: " + e.getMessage());
        }

        return "redirect:/profile";
    }
}
