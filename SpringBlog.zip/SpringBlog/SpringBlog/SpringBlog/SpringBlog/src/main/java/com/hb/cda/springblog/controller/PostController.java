package com.hb.cda.springblog.controller;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hb.cda.springblog.controller.dto.AddPostDTO;
import com.hb.cda.springblog.entity.Comment;
import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.Reaction;
import com.hb.cda.springblog.entity.User;
import com.hb.cda.springblog.repository.CommentRepository;
import com.hb.cda.springblog.repository.PostRepository;
import com.hb.cda.springblog.repository.ReactionRepository;
import com.hb.cda.springblog.repository.UserRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Controller
@Transactional
public class PostController {

    private final PostRepository postRepo;
    private final UserRepository userRepo;
    private final ReactionRepository reactRepo;
    private final CommentRepository commentRepo;

    public PostController(PostRepository postRepo, UserRepository userRepo,
                          ReactionRepository reactRepo, CommentRepository commentRepo) {
        this.postRepo = postRepo;
        this.userRepo = userRepo;
        this.reactRepo = reactRepo;
        this.commentRepo = commentRepo;
    }

    @GetMapping("/add-post")
    public String getPostForm(Model model) {
        model.addAttribute("addPostDTO", new AddPostDTO());
        return "post-form";
    }

    @PostMapping("/add-post")
    public String addPost(@Valid AddPostDTO addPostDTO, BindingResult bindingResult,
                          Model model, @AuthenticationPrincipal User user) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getFieldErrors());
            return "post-form";
        }
        Post post = new Post();
        post.setTitle(addPostDTO.getTitle());
        post.setContent(addPostDTO.getContent());
        post.setAuthor(user);
        post.setPostedAt(LocalDateTime.now());
        postRepo.save(post);
        return "redirect:/posts";
    }

    @GetMapping("/posts")
    public String listPosts(@RequestParam(defaultValue = "1") int page, Model model) {
        Pageable pageable = PageRequest.of(page - 1, 5, Sort.by("postedAt").descending());
        Page<Post> p = postRepo.findAll(pageable);
        model.addAttribute("posts", p.getContent());
        model.addAttribute("totalPages", p.getTotalPages());
        model.addAttribute("currentPage", page);
        return "posts";
    }

    @GetMapping("/post/{id}")
    public String getPost(@PathVariable String id, @AuthenticationPrincipal User user, Model model) {
        Optional<Post> postOpt = postRepo.findById(id);
        if (postOpt.isEmpty()) return "404";
        Post post = postOpt.get();
        model.addAttribute("post", post);
        model.addAttribute("reactionCounts", post.getReactionsCountByType());
        model.addAttribute("user", user);
        model.addAttribute("comments", commentRepo.findByPostOrderByCreatedAtDesc(post));
        return "post";
    }

    @PostMapping("/post/{id}")
    public String addReaction(@PathVariable String id, @RequestParam String type,
                              @AuthenticationPrincipal User user, RedirectAttributes ra) {
        Optional<Post> postOpt = postRepo.findById(id);
        if (postOpt.isEmpty()) return "redirect:/posts";

        Post post = postOpt.get();
        Optional<Reaction> rOpt = reactRepo.findByUserAndPost(user, post);
        Reaction r = rOpt.orElse(new Reaction(user, post));

        if (r.getType() != null && r.getType().equals(type)) {
            reactRepo.delete(r);
            ra.addFlashAttribute("message", "Reaction removed");
        } else {
            r.setType(type);
            reactRepo.save(r);
            ra.addFlashAttribute("message", "Reaction added!");
        }
        return "redirect:/post/" + id;
    }

    @PostMapping("/post/{id}/comment")
    public String addComment(@PathVariable String id, @RequestParam String content,
                             @AuthenticationPrincipal User user, RedirectAttributes ra) {
        Optional<Post> postOpt = postRepo.findById(id);
        if (postOpt.isEmpty() || content == null || content.trim().isEmpty()) {
            ra.addFlashAttribute("error", "Invalid comment");
            return "redirect:/post/" + id;
        }
        Comment c = new Comment(content.trim(), postOpt.get(), user);
        commentRepo.save(c);
        ra.addFlashAttribute("message", "Comment added!");
        return "redirect:/post/" + id;
    }

    @PostMapping("/post/{postId}/comment/{commentId}/delete")
    public String deleteComment(@PathVariable String postId, @PathVariable String commentId,
                                @AuthenticationPrincipal User user, RedirectAttributes ra) {
        Optional<Comment> cOpt = commentRepo.findById(commentId);
        if (cOpt.isEmpty()) {
            ra.addFlashAttribute("error", "Comment not found");
            return "redirect:/post/" + postId;
        }
        Comment c = cOpt.get();
        if (!c.getUser().equals(user) && !c.getPost().getAuthor().equals(user)) {
            ra.addFlashAttribute("error", "No permission");
            return "redirect:/post/" + postId;
        }
        commentRepo.delete(c);
        ra.addFlashAttribute("message", "Comment deleted");
        return "redirect:/post/" + postId;
    }
}