package com.hb.cda.springblog.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hb.cda.springblog.entity.Comment;
import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.User;

@Repository
public interface CommentRepository extends JpaRepository<Comment, String> {

    @Query("SELECT c FROM Comment c WHERE c.post = :post ORDER BY c.createdAt DESC")
    List<Comment> findByPostOrderByCreatedAtDesc(@Param("post") Post post);

    long countByUser(User user);

    // ✅ Added for post deletion cleanup
    void deleteAllByPost(Post post);
}
