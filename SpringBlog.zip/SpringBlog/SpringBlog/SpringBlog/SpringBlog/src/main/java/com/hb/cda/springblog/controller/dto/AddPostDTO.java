package com.hb.cda.springblog.controller.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AddPostDTO {
    @NotBlank
    @Size(max = 128)
    private String title;
    @NotBlank
    private String content;
    
    public AddPostDTO() {
    }

    public AddPostDTO(@NotBlank @Size(max = 128) String title, String content) {
        this.title = title;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
   
}
