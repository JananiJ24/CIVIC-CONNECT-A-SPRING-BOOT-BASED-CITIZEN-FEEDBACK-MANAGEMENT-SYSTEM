package com.hb.cda.springblog.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.Reaction;
import com.hb.cda.springblog.entity.User;

@Repository
public interface ReactionRepository extends JpaRepository<Reaction, String> {

    Optional<Reaction> findByUserAndPost(User user, Post post);

    @Query("SELECT r.type, COUNT(r) FROM Reaction r WHERE r.user = :user GROUP BY r.type")
    List<Object[]> countByReactionTypeForUser(@Param("user") User user);

    default Map<String, Integer> countByReactionTypeForUserMap(User user) {
        Map<String, Integer> result = new HashMap<>();
        for (Object[] row : countByReactionTypeForUser(user)) {
            String type = (String) row[0];
            Long count = (Long) row[1];
            result.put(type, count.intValue());
        }
        return result;
    }

    // ✅ Needed to remove reactions before post deletion
    void deleteAllByPost(Post post);
}
